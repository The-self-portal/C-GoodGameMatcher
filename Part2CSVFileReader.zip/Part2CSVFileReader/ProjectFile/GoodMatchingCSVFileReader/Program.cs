﻿using System;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;
using System.Diagnostics.CodeAnalysis;
using System.Collections.Generic;
using System.Linq;

namespace GoodMatchingCSVFileReader
{
    class Program
    {

        static void Main(string[] args)
        {


            FileReader file = new FileReader();
            Console.ReadLine();

        }

    }

    public class FileReader {


        private List<Person> allResultsList = new List<Person>();
        private long timeTaken;

        public FileReader()
        {
            var Watch = new System.Diagnostics.Stopwatch();

            Watch.Start();

        Regex inputCheck = new Regex("[A-Za-z]");
            List<string> names = new List<string>();
            List<char> gender = new List<char>();
            List<Person> Male = new List<Person>();
            List<Person> Female = new List<Person>();



            ////////////////////////////////////////////////////////////

            string CSVMatching1;
            string[] CSVMatching2;
            string basePath = AppContext.BaseDirectory;
            string inputResultsfilePath;
            Regex fileCheck = new Regex("[0-9@!#$%^&*)(?><.+=~`;:'\\|/\\{\\}\\[\\]]");
            Console.WriteLine("Please enter full file path (with filename.csv), drag and drop file (Default file is in application executable folder so you may drag and drop that for testing):");
            string userInput = Console.ReadLine();
            
            //
            /*

            HI IF YOU ARE RUNNING THIS FROM THE VISUAL STUDIO APP PLEASE DRAG AND DROP FILE FOR FULL EFFECT 
            */
            //



            Console.WriteLine(basePath);

            if (userInput == "-1")
            {

                inputResultsfilePath = basePath + @"Files\Input\matching.csv";
            }
            else
            {
                inputResultsfilePath = @userInput;
            }

            try
            {
                CSVMatching1 = File.ReadAllText(inputResultsfilePath);
                CSVMatching2 = File.ReadAllLines(inputResultsfilePath);

            }
            catch (Exception ex)
            {
                Console.WriteLine("You have entered an incorect file path please close the application and restart it");
                throw new ApplicationException("An incorrect file path has been entered");
            }
            /////////////////////////////////////////////////////////////




            if (!fileCheck.IsMatch(CSVMatching1))
            {
                Console.WriteLine("The file has no imperfections");
            }
            else
            {

                Console.WriteLine("The file contains bad characters please fix it and restart the application ");
                throw new ApplicationException("The file is bad");


            }





            ////////////////////////////////////////////////////////////////
            foreach (string item in CSVMatching2)
            {
                //Console.WriteLine("\n {0}", item);
                string[] rows = item.Split(',');
                names.Add(rows[0].Replace(" ", String.Empty));
                gender.Add(Convert.ToChar(rows[1].Replace(" ", String.Empty)));

            }





            for (int i = 0; i < names.Count; i++)
            {

                if ((gender[i] == 'm' || gender[i] == 'M') && inputCheck.IsMatch(names[i]))
                {
                    Male.Add(new Person(names[i], gender[i]));
                }
                else if ((gender[i] == 'f' || gender[i] == 'F') && inputCheck.IsMatch(names[i]))
                {
                    Female.Add(new Person(names[i], gender[i]));
                }
            }

            //Removing duplicates and sorting for to make it easier in future code
            Male = removeDuplicates(Male);
            Female = removeDuplicates(Female);




            // Inserting two names at a time to the sentence matcher
            startMatching(Male, Female);
            sortLsit();


            String fileName = DateTime.Now.ToString().Replace(" ", "").Replace(":", "_").Replace("/", "_") + "_Results.csv";
            Directory.CreateDirectory(@"C:\Files\Output\Results\");
            string outputResultsfilePath = @"C:\Files\Output\Results\" + fileName;
            StreamWriter outputFile = new StreamWriter(outputResultsfilePath, true);

            foreach (Person person in allResultsList) { 
            outputFile.WriteLine(person.getResult().getFinalString());
            }
            outputFile.Flush();

            Watch.Stop();

            timeTaken = Watch.ElapsedMilliseconds;
            fileLogger();
        }

        private List<Person> removeDuplicates(List<Person> aPersonList)
        {
            //Removing Doops

            foreach (Person item in aPersonList.ToArray()) {
                int counter = 0;
                string tempPersonName = item.getPersonName();
                char tempPersonGender = item.getPersonGender();

                foreach (Person nameGender in aPersonList) {
                    if (tempPersonName == nameGender.getPersonName() && tempPersonGender == nameGender.getPersonGender() ) {

                        counter++;

                    }
                }

                if (counter > 1) {

                    aPersonList.Remove(item);
                
                }

            
            }



            return aPersonList;


        }

        //Starts matching each male with each female
        private void startMatching(List<Person> Male , List<Person> Female) {

            foreach (Person m in Male)
            {

                foreach (Person f in Female)
                {

                    Matcher CsvIn = new Matcher(m.getPersonName(), f.getPersonName());
                    allResultsList.Add(new Person(m.getPersonName(), CsvIn.getfinalSentence(), CsvIn.getFinalPercentage()));
                }

            }
        }

        private void sortLsit() {

            //Final Sorting of last list 

            allResultsList = allResultsList.OrderBy(o => o.getResult().getFinalPercent())
                                .ThenByDescending(o => o.getPersonName())
                                .ToList();
            allResultsList.Reverse();
            Console.WriteLine("--------------------------------------------");


            foreach (Person person in allResultsList.ToArray())
            {

                Console.WriteLine("\n{0}", person.getResult().getFinalString());



            }

        }

        // logs everything in the run
        private void fileLogger() {
            string basePath = AppContext.BaseDirectory;
            Directory.CreateDirectory(@"C:\Files\Output\Logs\");
            String fileName = DateTime.Now.ToString().Replace(" ", "").Replace(":", "_").Replace("/", "_") + "_Log.csv";
            string outputResultsfilePath = @"C:\Files\Output\Logs\" + fileName;
            StreamWriter outputFile = new StreamWriter(outputResultsfilePath, true);

            outputFile.WriteLine("The matcher took : {0} milliseconds",timeTaken);

            int average;
            int max = 0;
            string maxSent = "";
            string maxPerson = "";
            int temp = 0;
            foreach (Person p in allResultsList) {

                temp += p.getResult().getFinalPercent();
                if (p.getResult().getFinalPercent() > max)
                {

                    max = p.getResult().getFinalPercent();
                    maxSent = p.getResult().getFinalString();
                    maxPerson = p.getPersonName();
                }
            }

            

            average = temp / allResultsList.Count;
            outputFile.WriteLine("The best matched person was : {0}", maxPerson);
            outputFile.WriteLine("The best goodMatch was : {0}", maxSent);
            outputFile.WriteLine("The max goodMatch was : {0}%", max);
            outputFile.WriteLine("The average goodMatch was : {0}%", average);

            outputFile.Flush();




        }



    }

    //class to handle matching 
    public class Matcher
    {

        private string matchingSentence = "";
        private string numberString = "";
        private string finalString = "";
        private int finalPercentage;


        public Matcher(string bName, string gName)
        {
            Console.WriteLine("\n");
            sentenceBuilder(bName,gName);
            setSentenceCounter(matchingSentence);
            countNumberString(numberString);
        }


        //assigns match sentence
        private void sentenceBuilder(string bName, string gName)
        {

         matchingSentence = bName + " matches " + gName;
           

        }

        //does counting to get number of each letter
        private void setSentenceCounter(string name)
        {

            ArrayList usedLetterList = new ArrayList();
            char temp;
            int count = 0;
            while (count < name.Length)
            {
                temp = name[count];
                int tempCount = 0;

                if (!(usedLetterList.Contains(temp) || temp == Convert.ToChar(" ")))
                {

                    int watch = count;

                    while (watch < name.Length)
                    {

                        if (temp == name[watch])
                        {
                            tempCount++;


                        }
                        watch++;
                    }
                    Console.WriteLine("{0} \n {1}", name, numberString);
                    usedLetterList.Add(temp);
                    numberString += tempCount;
                }

                count++;

            }



        }

        // gets the /5 of match between two names 
        private void countNumberString(string numStrng)
        {
            Console.WriteLine("\n");
            string tempNumString = "";
            int frontNum = 0;
            int lastNum = numStrng.Length - 1;

            while (numStrng.Length > 2)
            {

                if (frontNum < lastNum)
                {
                    int adder = int.Parse(Convert.ToString(numStrng[frontNum])) + int.Parse(Convert.ToString(numStrng[lastNum]));
                    tempNumString += Convert.ToString(adder);
                    Console.WriteLine("* {0}", numStrng);
                    Console.WriteLine("    * {0}", tempNumString);
                    frontNum++;
                    lastNum--;

                }
                else if (frontNum == lastNum)
                {

                    tempNumString += numStrng[frontNum];
                    Console.WriteLine("* {0}", numStrng);
                    Console.WriteLine("    * {0}", tempNumString);
                    numStrng = tempNumString;
                    tempNumString = "";
                    frontNum = 0;
                    lastNum = numStrng.Length - 1; ;
                    Console.WriteLine("\n");

                }
                else
                {
                    Console.WriteLine("* {0}", numStrng);
                    Console.WriteLine("    * {0}", tempNumString);
                    numStrng = tempNumString;
                    tempNumString = "";
                    frontNum = 0;
                    lastNum = numStrng.Length - 1;
                    Console.WriteLine("\n");


                }
            }

            Console.WriteLine("{0} : {1}%", matchingSentence, numStrng);

            finalString = matchingSentence + " : " + numStrng + "%";
            finalPercentage = int.Parse(numStrng);

        }


        public string getfinalSentence() {

            return finalString;
        }

        public int getFinalPercentage() {
            return finalPercentage;
        }


    }

    // represents obe person as an object
    public class Person
    {

        private string name;
        private char gender;
        private results result ;


        public Person(string aName, char aGender)
        {

           name = aName;
            gender = aGender;
        }

        public Person(string fname ,string fResult , int fPercent) {
            name = fname;
            result = new results(fResult,fPercent);
        
        }

        public string getPersonName() {

            return name;
        }

        public char getPersonGender() {

            return gender;
        }


        public results getResult() {

            return result; 
        }


        //Mostly used for testing purposes even tho visual studio has advanced debuging : ) 
        public void ToString() {

            Console.WriteLine("{0} : {1}", name,gender);
        }


       

        
        }

    // represents the results of each match sequence
    public class results
    {

        private string finalstring;
        private int finalPercentage;

        public results(string a, int b)
        {

            finalstring = a;
            finalPercentage = b;
        }


        public string getFinalString() {
            return finalstring;
        }

        public int getFinalPercent()
        {
            return finalPercentage;
        }

    }
}
